package com.example.mna.customlistview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private CustomListViewAdapter customListViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

          final String[] bookTitle = new String[]{
                  "Batouala",
                  "The Giver",
                  "How to kill a MockingBird",
                  "The complete C++ an QT developer",
                  "Titanic",
                  "The Shanara Chronicles",
                  "The Hobbit",
                  "Java in a Nutshell",
                  "The Social Network",
                  "Game dev all in One",
                  "The Kite Runner"

          };

          final String[] bookPages = new String[]{
                  "300 pages",
                  "350 pages",
                  "980 pages",
                  "1200 pages",
                  "350 pages",
                  "120 pages",
                  "180 pages",
                  "2000 pages",
                  "204 pages",
                  "1000 pages",
                  "92 pages"
              };
          final String[] bookAuthor = new String[]{
                  "Rene Maran",
                  "Lois Lowry",
                  "Sonell Authoris",
                  "Mumbere and Conrad",
                  "Simon Adams",
                  "J. K. Rowlings",
                  "Kennedy J. F.",
                  "Bush Walter, George",
                  "Lynda and Udemy",
                  "Mauricio Pat"
          };

        ArrayList<HashMap<String, String>> autherList = new ArrayList<>();

        for (int i = 0; i < 10; i++){
            HashMap<String, String> data = new HashMap<>();
            data.put("title", bookTitle[i]);
            data.put("pages", bookPages[i]);
            data.put("author", bookAuthor[i]);

            autherList.add(data);
        }

        listView = (ListView) findViewById(R.id.list);

        //Setup adapter
        customListViewAdapter = new CustomListViewAdapter(getApplicationContext(), autherList);
        listView.setAdapter(customListViewAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                int myPosition = position;

                String itemClickedId = listView.getItemAtPosition(myPosition).toString();

                Toast.makeText(getApplicationContext(), "Id Clicked: " +itemClickedId, Toast.LENGTH_LONG).show();




            }
        });

    }
}

